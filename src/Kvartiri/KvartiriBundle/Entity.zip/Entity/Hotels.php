<?php

namespace Kvartiri\KvartiriBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Hotels
 *
 * @ORM\Table("hotels")
 * @ORM\Entity(repositoryClass="Kvartiri\KvartiriBundle\Repository\HotelsRepository")
 */
class Hotels
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    public function __construct()
    {
//        $this->contacts = new \Doctrine\Common\Collections\ArrayCollection();
//        $this->hotelType = new \Doctrine\Common\Collections\ArrayCollection();
//        $this->hotelService = new \Doctrine\Common\Collections\ArrayCollection();
        $this->rooms = new \Doctrine\Common\Collections\ArrayCollection();
        $this->seasons = new \Doctrine\Common\Collections\ArrayCollection();
        $this->images = new \Doctrine\Common\Collections\ArrayCollection();
        $this->video = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=125)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="remarks", type="string", length=255)
     */
    private $remarks;

    /**
     * @ORM\ManyToOne(targetEntity="Kvartiri\KvartiriBundle\Entity\Cities", inversedBy="hotels", cascade={"persist"} )
     * @ORM\JoinColumn(nullable=true)
     */
    private $city;

    /**
     * @var integer
     *
     * @ORM\Column(name="hotel_type", type="integer")
     */
    private $hotelType;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\HotelSeasons", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $hotelSeasons;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\Rooms", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $rooms;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\Images", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $images;


    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\Videos", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $videos;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\PromotionEarlyBooking", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $promotionEarlyBooking;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\PromotionFixedDates", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $promotionFixedDates;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\PromotionGroup", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $promotionGroup;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\PromotionMoreNights", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $promotionMoreNights;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\PromotionPeriod", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $promotionPeriod;

    /**
     * @ORM\OneToMany(targetEntity="Kvartiri\KvartiriBundle\Entity\ReductionChildren", mappedBy="hotel", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $reductionChildren;




    

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Hotels
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Hotels
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set remarks
     *
     * @param string $remarks
     * @return Hotels
     */
    public function setRemarks($remarks)
    {
        $this->remarks = $remarks;

        return $this;
    }

    /**
     * Get remarks
     *
     * @return string 
     */
    public function getRemarks()
    {
        return $this->remarks;
    }

    /**
     * Set city
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Cities $city
     * @return Hotels
     */
    public function setCity(\Kvartiri\KvartiriBundle\Entity\Cities $city = null)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return \Kvartiri\KvartiriBundle\Entity\Cities 
     */
    public function getCity()
    {
        return $this->city;
    }


    /**
     * Add hotelSeasons
     *
     * @param \Kvartiri\KvartiriBundle\Entity\HotelSeasons $hotelSeasons
     * @return Hotels
     */
    public function addHotelSeason(\Kvartiri\KvartiriBundle\Entity\HotelSeasons $hotelSeasons)
    {
        $this->hotelSeasons[] = $hotelSeasons;

        return $this;
    }

    /**
     * Remove hotelSeasons
     *
     * @param \Kvartiri\KvartiriBundle\Entity\HotelSeasons $hotelSeasons
     */
    public function removeHotelSeason(\Kvartiri\KvartiriBundle\Entity\HotelSeasons $hotelSeasons)
    {
        $this->hotelSeasons->removeElement($hotelSeasons);
    }

    /**
     * Get hotelSeasons
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getHotelSeasons()
    {
        return $this->hotelSeasons;
    }

    /**
     * Add rooms
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Rooms $rooms
     * @return Hotels
     */
    public function addRoom(\Kvartiri\KvartiriBundle\Entity\Rooms $rooms)
    {
        $this->rooms[] = $rooms;

        return $this;
    }

    /**
     * Remove rooms
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Rooms $rooms
     */
    public function removeRoom(\Kvartiri\KvartiriBundle\Entity\Rooms $rooms)
    {
        $this->rooms->removeElement($rooms);
    }

    /**
     * Get rooms
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getRooms()
    {
        return $this->rooms;
    }

    /**
     * Add images
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Images $images
     * @return Hotels
     */
    public function addImage(\Kvartiri\KvartiriBundle\Entity\Images $images)
    {
        $this->images[] = $images;

        return $this;
    }

    /**
     * Remove images
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Images $images
     */
    public function removeImage(\Kvartiri\KvartiriBundle\Entity\Images $images)
    {
        $this->images->removeElement($images);
    }

    /**
     * Get images
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getImages()
    {
        return $this->images;
    }

    

    /**
     * Add videos
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Videos $videos
     * @return Hotels
     */
    public function addVideo(\Kvartiri\KvartiriBundle\Entity\Videos $videos)
    {
        $this->videos[] = $videos;

        return $this;
    }

    /**
     * Remove videos
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Videos $videos
     */
    public function removeVideo(\Kvartiri\KvartiriBundle\Entity\Videos $videos)
    {
        $this->videos->removeElement($videos);
    }

    /**
     * Get videos
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getVideos()
    {
        return $this->videos;
    }


    /**
     * Add promotionFixedDates
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionFixedDates $promotionFixedDates
     * @return Hotels
     */
    public function addPromotionFixedDate(\Kvartiri\KvartiriBundle\Entity\PromotionFixedDates $promotionFixedDates)
    {
        $this->promotionFixedDates[] = $promotionFixedDates;

        return $this;
    }

    /**
     * Remove promotionFixedDates
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionFixedDates $promotionFixedDates
     */
    public function removePromotionFixedDate(\Kvartiri\KvartiriBundle\Entity\PromotionFixedDates $promotionFixedDates)
    {
        $this->promotionFixedDates->removeElement($promotionFixedDates);
    }

    /**
     * Get promotionFixedDates
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPromotionFixedDates()
    {
        return $this->promotionFixedDates;
    }

    /**
     * Add promotionGroup
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionGroup $promotionGroup
     * @return Hotels
     */
    public function addPromotionGroup(\Kvartiri\KvartiriBundle\Entity\PromotionGroup $promotionGroup)
    {
        $this->promotionGroup[] = $promotionGroup;

        return $this;
    }

    /**
     * Remove promotionGroup
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionGroup $promotionGroup
     */
    public function removePromotionGroup(\Kvartiri\KvartiriBundle\Entity\PromotionGroup $promotionGroup)
    {
        $this->promotionGroup->removeElement($promotionGroup);
    }

    /**
     * Get promotionGroup
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPromotionGroup()
    {
        return $this->promotionGroup;
    }

    /**
     * Add promotionMoreNights
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionMoreNights $promotionMoreNights
     * @return Hotels
     */
    public function addPromotionMoreNight(\Kvartiri\KvartiriBundle\Entity\PromotionMoreNights $promotionMoreNights)
    {
        $this->promotionMoreNights[] = $promotionMoreNights;

        return $this;
    }

    /**
     * Remove promotionMoreNights
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionMoreNights $promotionMoreNights
     */
    public function removePromotionMoreNight(\Kvartiri\KvartiriBundle\Entity\PromotionMoreNights $promotionMoreNights)
    {
        $this->promotionMoreNights->removeElement($promotionMoreNights);
    }

    /**
     * Get promotionMoreNights
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPromotionMoreNights()
    {
        return $this->promotionMoreNights;
    }

    /**
     * Add promotionPeriod
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionPeriod $promotionPeriod
     * @return Hotels
     */
    public function addPromotionPeriod(\Kvartiri\KvartiriBundle\Entity\PromotionPeriod $promotionPeriod)
    {
        $this->promotionPeriod[] = $promotionPeriod;

        return $this;
    }

    /**
     * Remove promotionPeriod
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionPeriod $promotionPeriod
     */
    public function removePromotionPeriod(\Kvartiri\KvartiriBundle\Entity\PromotionPeriod $promotionPeriod)
    {
        $this->promotionPeriod->removeElement($promotionPeriod);
    }

    /**
     * Get promotionPeriod
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPromotionPeriod()
    {
        return $this->promotionPeriod;
    }

    /**
     * Add reductionChildren
     *
     * @param \Kvartiri\KvartiriBundle\Entity\ReductionChildren $reductionChildren
     * @return Hotels
     */
    public function addReductionChild(\Kvartiri\KvartiriBundle\Entity\ReductionChildren $reductionChildren)
    {
        $this->reductionChildren[] = $reductionChildren;

        return $this;
    }

    /**
     * Remove reductionChildren
     *
     * @param \Kvartiri\KvartiriBundle\Entity\ReductionChildren $reductionChildren
     */
    public function removeReductionChild(\Kvartiri\KvartiriBundle\Entity\ReductionChildren $reductionChildren)
    {
        $this->reductionChildren->removeElement($reductionChildren);
    }

    /**
     * Get reductionChildren
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getReductionChildren()
    {
        return $this->reductionChildren;
    }

    /**
     * Add promotionEarlyBooking
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionEarlyBooking $promotionEarlyBooking
     * @return Hotels
     */
    public function addPromotionEarlyBooking(\Kvartiri\KvartiriBundle\Entity\PromotionEarlyBooking $promotionEarlyBooking)
    {
        $this->promotionEarlyBooking[] = $promotionEarlyBooking;

        return $this;
    }

    /**
     * Remove promotionEarlyBooking
     *
     * @param \Kvartiri\KvartiriBundle\Entity\PromotionEarlyBooking $promotionEarlyBooking
     */
    public function removePromotionEarlyBooking(\Kvartiri\KvartiriBundle\Entity\PromotionEarlyBooking $promotionEarlyBooking)
    {
        $this->promotionEarlyBooking->removeElement($promotionEarlyBooking);
    }

    /**
     * Get promotionEarlyBooking
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPromotionEarlyBooking()
    {
        return $this->promotionEarlyBooking;
    }


    /**
     * Set hotelType
     *
     * @param integer $hotelType
     * @return Hotels
     */
    public function setHotelType($hotelType)
    {
        $this->hotelType = $hotelType;

        return $this;
    }

    /**
     * Get hotelType
     *
     * @return integer 
     */
    public function getHotelType()
    {
        return $this->hotelType;
    }
}
