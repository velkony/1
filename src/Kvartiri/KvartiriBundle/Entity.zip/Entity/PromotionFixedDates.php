<?php

namespace Kvartiri\KvartiriBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * PromotionFixedDates
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Kvartiri\KvartiriBundle\Repository\PromotionFixedDatesRepository")
 */
class PromotionFixedDates
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fixedDate", type="datetime")
     */
    private $fixedDate;

    /**
     * @var float
     *
     * @ORM\Column(name="discount", type="float")
     */
    private $discount;

    /**
     * @ORM\ManyToOne(targetEntity="Kvartiri\KvartiriBundle\Entity\Hotels", inversedBy="promotionFixedDates")
     * @ORM\JoinColumn(nullable=true)
     */
    private $hotel;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fixedDate
     *
     * @param \DateTime $fixedDate
     * @return PromotionFixedDates
     */
    public function setFixedDate($fixedDate)
    {
        $this->fixedDate = $fixedDate;

        return $this;
    }

    /**
     * Get fixedDate
     *
     * @return \DateTime 
     */
    public function getFixedDate()
    {
        return $this->fixedDate;
    }

    /**
     * Set discount
     *
     * @param float $discount
     * @return PromotionFixedDates
     */
    public function setDiscount($discount)
    {
        $this->discount = $discount;

        return $this;
    }

    /**
     * Get discount
     *
     * @return float 
     */
    public function getDiscount()
    {
        return $this->discount;
    }

    /**
     * Set hotel
     *
     * @param \Kvartiri\KvartiriBundle\Entity\Hotels $hotel
     * @return PromotionFixedDates
     */
    public function setHotel(\Kvartiri\KvartiriBundle\Entity\Hotels $hotel = null)
    {
        $this->hotel = $hotel;

        return $this;
    }

    /**
     * Get hotel
     *
     * @return \Kvartiri\KvartiriBundle\Entity\Hotels 
     */
    public function getHotel()
    {
        return $this->hotel;
    }
}
